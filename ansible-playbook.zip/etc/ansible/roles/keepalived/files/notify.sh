#!/bin/bash
VIP=172.16.10.1
VIP=172.16.10.2



notify() {
        mailsubject="`hostname` to be $1:$VIP is floating."
        mailcontent="`date +%F %H:%M:%S`,vrrp transition,`hostname` changed to be $1"
        echo $mailsubject | mail -s "$mailcontent" root@localhost
}


case $1 in
master)
        systemctl start nginx.service
        notify master
        ;;
backup)
        systemctl start nginx.service
        notify backup
        ;;
fault)
        systemctl stop nginx.service
        notify fault

esac
